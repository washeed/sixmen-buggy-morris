six mens morris in python

uses alpha beta pruning and minimax algorithm 

player is A and ai is I. the program asks for the move twice due to instances error but it ignores the extra inputs. 

